<?php

// $host = '31.11.39.239';
// $db   = 'Sql1882760_2';
// $user = 'Sql1882760';
// $pass = 'K:PH:vQ6Tw:@6dSL';
$host = 'localhost';
$db   = 'u567802240_kdker';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    echo "Connected successfully!<br>";



    $sql = "
    ALTER TABLE suppliers
    ADD brand VARCHAR(255) NULL,
    ADD agency_address VARCHAR(255) NULL,
    ADD agency_telephone VARCHAR(255) NULL,
    ADD agency_mobile VARCHAR(50) NULL,
    ADD agency_address_1 VARCHAR(50) NULL,
    ADD agency_address_2 VARCHAR(50) NULL,
    ADD agency_agent VARCHAR(255) NULL,
    ADD agency_email VARCHAR(255) NULL,
    ADD agency_pec VARCHAR(255) NULL,
    ADD agency_vat VARCHAR(255) NULL,
    ADD agency_iban VARCHAR(255) NULL,
    ADD agency_sdi VARCHAR(255) NULL,
    ADD agency_payment VARCHAR(255) NULL
";


    // Execute SQL
    $pdo->exec($sql);
    echo "Table 'suppliers' updated successfully!<br>";

} catch (PDOException $e) {
    echo "Connection failed or error creating table: " . $e->getMessage();
}
